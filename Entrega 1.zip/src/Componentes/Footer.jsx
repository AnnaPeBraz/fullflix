import React from "react";

export function Footer(props){
    return(
        <footer>{props.texto}</footer>
    )
}