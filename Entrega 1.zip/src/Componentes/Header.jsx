

export const Header = () =>{
    return(
        <div>
            <img src="../src/assets/images/cabeca.png"/>
            <h2>HOME</h2>

        </div>
    )
}