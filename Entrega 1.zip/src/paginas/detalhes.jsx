import { Footer } from "../Componentes/Footer";
import { Header } from "../Componentes/Header";

export function Detalhes(){
    return(
        <div>
            <Header/>
            <main>
                Div/Main do meio
            </main>
            <Footer/>
        </div>
    )
}